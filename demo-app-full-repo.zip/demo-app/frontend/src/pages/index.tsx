export default function Home(){
  return <main style={{fontFamily:'system-ui',padding:40}}>
    <h1>Demo App — Scaffold</h1>
    <p>Deploy succeeded. Replace this UI with the full app when ready.</p>
  </main>
}
