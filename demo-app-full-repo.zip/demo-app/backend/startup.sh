#!/usr/bin/env bash
set -e
FFDIR=/home/site/tools/ffmpeg
FFBIN="$FFDIR/ffmpeg"
if [ ! -f "$FFBIN" ]; then
  mkdir -p "$FFDIR"
  echo "Downloading static ffmpeg..."
  curl -L -o "$FFDIR/ffmpeg.tar.xz" https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-amd64-static.tar.xz
  tar -xJf "$FFDIR/ffmpeg.tar.xz" -C "$FFDIR" --strip-components=1
  chmod +x "$FFDIR/ffmpeg"
fi
export PATH="$FFDIR:$PATH"
exec gunicorn --bind=0.0.0.0:8000 app.main:app
