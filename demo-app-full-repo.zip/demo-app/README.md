# Video → Walkthrough & FAQ — One‑Click Azure Deploy (Full App)

This repository lets you deploy the **full app** (API + Web) to Azure in minutes and then redeploy on every push to `main` using GitHub Actions.

## 🚀 Fast path
1) **Create a new PUBLIC repo** in your GitHub (name: Demo-App).  
2) Upload everything from this folder (`demo-app/`) into your repo.  
3) Click the **Deploy to Azure** button below and fill the form (creates the API & Web App + app settings).  
4) In Azure Portal, open each Web App → **Get publish profile** → paste into GitHub **Secrets** (see names below).  
5) Push to `main`. The action deploys both apps. Visit the **Web app URL**.

[![Deploy to Azure](https://aka.ms/deploytoazurebutton)](https://portal.azure.com/#create/Microsoft.Template/uri/https://raw.githubusercontent.com/tousibsarker22/Demo-App/main/infra/azuredeploy.json)
